# 🚀 دليل نشر تطبيق التمويل على Hostinger

## 📋 المتطلبات الأساسية

قبل البدء، تأكد من توفر:
- ✅ حساب Hostinger مع استضافة تدعم Node.js
- ✅ دومين مسجل ومربوط بالاستضافة
- ✅ صلاحيات SSH للوصول للخادم
- ✅ قاعدة بيانات MySQL

---

## 📦 الخطوة 1: إعداد قاعدة البيانات MySQL

### 1.1 إنشاء قاعدة البيانات

1. **سجل دخول إلى لوحة تحكم Hostinger (hPanel)**
2. **اذهب إلى قسم "Databases" أو "قواعد البيانات"**
3. **اضغط على "MySQL Databases" أو "إدارة قواعد البيانات"**
4. **أنشئ قاعدة بيانات جديدة:**
   - اسم القاعدة: `tamweel` (أو أي اسم تفضله)
   - سيتم إنشاؤها بشكل: `u123456789_tamweel`

### 1.2 إنشاء مستخدم للقاعدة

1. **في نفس الصفحة، أنشئ مستخدم جديد:**
   - اسم المستخدم: `tamweel_user`
   - كلمة المرور: **أنشئ كلمة مرور قوية**
   - احفظ هذه المعلومات في مكان آمن!

2. **اربط المستخدم بقاعدة البيانات:**
   - اختر "ALL PRIVILEGES" أو "كل الصلاحيات"
   - احفظ التغييرات

### 1.3 سجل معلومات الاتصال

```
DB_HOST: localhost
DB_USER: u123456789_tamweel_user
DB_PASSWORD: كلمة_المرور_القوية
DB_NAME: u123456789_tamweel
```

---

## 📁 الخطوة 2: رفع الملفات عبر SSH

### 2.1 الاتصال بالخادم عبر SSH

```bash
ssh u123456789@yourdomain.com -p 65002
# أدخل كلمة المرور عند الطلب
```

> **ملاحظة:** رقم المنفذ (port) قد يختلف، تحقق من لوحة التحكم.

### 2.2 انتقل إلى مجلد public_html

```bash
cd ~/public_html
```

### 2.3 حذف الملفات الافتراضية (اختياري)

```bash
rm -rf *
```

### 2.4 رفع ملفات المشروع

**الطريقة 1: رفع ملف مضغوط**

على جهازك المحلي، اضغط مجلد `hostinger-deploy`:

```bash
cd /home/user/webapp
tar -czf tamweel-app.tar.gz hostinger-deploy/
```

ثم ارفعه عبر FTP أو لوحة التحكم، وفك الضغط على الخادم:

```bash
cd ~/public_html
tar -xzf tamweel-app.tar.gz
mv hostinger-deploy/* .
rm -rf hostinger-deploy tamweel-app.tar.gz
```

**الطريقة 2: استخدام Git (الأفضل)**

```bash
cd ~/public_html
git clone https://github.com/basealsyed2015-source/Expense-Master.git .
cd hostinger-deploy
mv * ../
cd ..
rm -rf hostinger-deploy
```

---

## ⚙️ الخطوة 3: تثبيت المتطلبات

### 3.1 تثبيت Node.js (إذا لم يكن مثبتاً)

```bash
# تحقق من نسخة Node.js
node --version
npm --version

# إذا لم يكن مثبتاً، اتصل بدعم Hostinger لتفعيله
```

### 3.2 تثبيت حزم NPM

```bash
cd ~/public_html
npm install
```

---

## 🔧 الخطوة 4: إعداد ملف البيئة

### 4.1 نسخ ملف الإعدادات

```bash
cp .env.example .env
```

### 4.2 تعديل ملف .env

```bash
nano .env
# أو استخدم vi إذا كنت معتاداً عليه
```

**أدخل معلومات قاعدة البيانات:**

```env
PORT=3000
NODE_ENV=production

DB_HOST=localhost
DB_USER=u123456789_tamweel_user
DB_PASSWORD=كلمة_المرور_التي_أنشأتها
DB_NAME=u123456789_tamweel

SESSION_SECRET=قم_بتوليد_مفتاح_عشوائي_طويل_هنا
APP_URL=https://yourdomain.com
```

**لحفظ الملف:**
- في nano: اضغط `Ctrl + X` ثم `Y` ثم `Enter`
- في vi: اضغط `ESC` ثم اكتب `:wq` ثم `Enter`

---

## 🗄️ الخطوة 5: إعداد قاعدة البيانات

### 5.1 تشغيل سكريبت الإعداد

```bash
npm run setup-db
```

هذا السكريبت سيقوم بـ:
- ✅ إنشاء جميع الجداول
- ✅ إدخال البيانات الأولية
- ✅ إنشاء الحسابات الافتراضية

### 5.2 تحقق من نجاح العملية

يجب أن تظهر رسالة:

```
✅ Database setup completed successfully!

📝 Default accounts:
   Superadmin: superadmin / SuperAdmin@2025
   Admin:      admin / Admin@2025
   Employee:   admin1 / Admin1@2025
```

---

## 🚀 الخطوة 6: تشغيل التطبيق

### 6.1 تشغيل باستخدام PM2 (موصى به للإنتاج)

```bash
# تثبيت PM2 عالمياً
npm install -g pm2

# تشغيل التطبيق
pm2 start server.js --name "tamweel-app"

# حفظ قائمة التطبيقات
pm2 save

# إعداد التشغيل التلقائي عند إعادة التشغيل
pm2 startup
```

### 6.2 التحقق من حالة التطبيق

```bash
pm2 status
pm2 logs tamweel-app --lines 50
```

### 6.3 أوامر PM2 المفيدة

```bash
# إعادة تشغيل
pm2 restart tamweel-app

# إيقاف
pm2 stop tamweel-app

# عرض السجلات
pm2 logs tamweel-app

# حذف من القائمة
pm2 delete tamweel-app
```

---

## 🌐 الخطوة 7: إعداد Apache/Nginx

### 7.1 تحقق من ملف .htaccess

تأكد من وجود ملف `.htaccess` في مجلد `public_html`:

```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ http://localhost:3000/$1 [P,L]
```

### 7.2 تفعيل mod_proxy (إذا لزم الأمر)

قد تحتاج للتواصل مع دعم Hostinger لتفعيل:
- `mod_proxy`
- `mod_proxy_http`

---

## 🔒 الخطوة 8: تفعيل SSL (HTTPS)

### 8.1 من لوحة تحكم Hostinger

1. **اذهب إلى قسم "SSL"**
2. **اختر دومينك**
3. **اضغط على "Install SSL"**
4. **اختر "Free SSL" (Let's Encrypt)**
5. **انتظر حتى يتم التفعيل (5-10 دقائق)**

### 8.2 فرض HTTPS

تم إضافته بالفعل في ملف `.htaccess`، ولكن تحقق من هذه الأسطر:

```apache
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

---

## ✅ الخطوة 9: الاختبار

### 9.1 اختبر الموقع

افتح المتصفح واذهب إلى:

```
https://yourdomain.com
```

### 9.2 اختبر تسجيل الدخول

استخدم الحسابات الافتراضية:

**المدير العام:**
- اسم المستخدم: `superadmin`
- كلمة المرور: `SuperAdmin@2025`

**المدير:**
- اسم المستخدم: `admin`
- كلمة المرور: `Admin@2025`

### 9.3 اختبر الصفحات

- ✅ الصفحة الرئيسية: `https://yourdomain.com`
- ✅ تسجيل الدخول: `https://yourdomain.com/login`
- ✅ النسب والأسعار: `https://yourdomain.com/admin/rates?tenant_id=1`
- ✅ التقارير: `https://yourdomain.com/admin/reports/customers`

---

## 🔧 استكشاف الأخطاء

### المشكلة: الموقع لا يعمل

**الحل:**

```bash
# تحقق من حالة PM2
pm2 status

# اعرض السجلات
pm2 logs tamweel-app --lines 100

# أعد التشغيل
pm2 restart tamweel-app
```

### المشكلة: خطأ في قاعدة البيانات

**الحل:**

```bash
# تحقق من ملف .env
cat .env

# اختبر الاتصال بقاعدة البيانات
mysql -u u123456789_tamweel_user -p u123456789_tamweel
```

### المشكلة: 502 Bad Gateway

**الحل:**

```bash
# تأكد من أن التطبيق يعمل
pm2 status

# تحقق من المنفذ
netstat -tuln | grep 3000

# أعد تشغيل Apache
sudo service apache2 restart
```

### المشكلة: الملفات الثابتة لا تعمل

**الحل:**

```bash
# تحقق من صلاحيات المجلد public
chmod -R 755 ~/public_html/public
```

---

## 📊 المراقبة والصيانة

### مراقبة الأداء

```bash
# عرض استخدام الموارد
pm2 monit

# عرض السجلات المباشرة
pm2 logs tamweel-app --lines 50 --raw
```

### النسخ الاحتياطي

**قاعدة البيانات:**

```bash
# نسخ احتياطي
mysqldump -u u123456789_tamweel_user -p u123456789_tamweel > backup_$(date +%Y%m%d).sql

# استعادة
mysql -u u123456789_tamweel_user -p u123456789_tamweel < backup_20241218.sql
```

**الملفات:**

```bash
cd ~/
tar -czf tamweel_backup_$(date +%Y%m%d).tar.gz public_html/
```

---

## 🎉 تهانينا!

✅ التطبيق الآن يعمل على Hostinger بنجاح!

### الخطوات التالية:

1. **غيّر كلمات المرور الافتراضية** من لوحة التحكم
2. **أضف مستخدمين جدد** حسب الحاجة
3. **اضبط إعدادات البنوك والنسب** من الإعدادات
4. **ابدأ في استخدام النظام** بإضافة العملاء والطلبات

---

## 📞 الدعم

إذا واجهت أي مشكلة:

1. **راجع السجلات:** `pm2 logs tamweel-app`
2. **تحقق من الإعدادات:** `cat .env`
3. **تواصل مع دعم Hostinger** للمساعدة في إعدادات الخادم

---

## 📝 ملاحظات مهمة

⚠️ **الأمان:**
- غيّر كلمات المرور الافتراضية فوراً
- احتفظ بنسخ احتياطية دورية
- راقب السجلات بانتظام

⚠️ **الأداء:**
- استخدم PM2 للحصول على أفضل أداء
- فعّل الكاشينج في Apache
- راقب استخدام الموارد

⚠️ **التحديثات:**
- احتفظ بنسخة احتياطية قبل أي تحديث
- اختبر التحديثات في بيئة تطوير أولاً

---

**تم إعداد هذا الدليل بواسطة:** GenSpark AI Developer
**التاريخ:** ديسمبر 2024
**الإصدار:** 1.0
