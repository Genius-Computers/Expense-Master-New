# 🚀 دليل التنصيب السريع - 10 خطوات فقط!

## ⏱️ الوقت المتوقع: 15-20 دقيقة

---

## الخطوة 1️⃣: إنشاء قاعدة البيانات

1. سجل دخول إلى **Hostinger hPanel**
2. اذهب إلى **Databases → MySQL Databases**
3. اضغط **Create New Database**:
   - الاسم: `tamweel`
   - احفظ معلومات الاتصال:
     ```
     Host: localhost
     Database: u123456_tamweel
     Username: u123456_tamweel
     Password: (كلمة مرور قوية)
     ```

---

## الخطوة 2️⃣: رفع الملفات

### الطريقة الأولى: File Manager (الأسهل)

1. في hPanel، اذهب إلى **Files → File Manager**
2. افتح مجلد `public_html`
3. احذف الملفات الموجودة (اختياري)
4. اضغط **Upload** وارفع ملف `tamweel-hostinger-v1.0.tar.gz`
5. اضغط بزر الماوس الأيمن على الملف → **Extract**
6. انقل محتويات `hostinger-deploy` إلى `public_html`

### الطريقة الثانية: SSH (للمحترفين)

```bash
ssh u123456@yourdomain.com -p 65002
cd ~/public_html
# ارفع الملف ثم:
tar -xzf tamweel-hostinger-v1.0.tar.gz
mv hostinger-deploy/* .
rm -rf hostinger-deploy tamweel-hostinger-v1.0.tar.gz
```

---

## الخطوة 3️⃣: تعديل ملف .env

```bash
# عبر File Manager أو SSH
cp .env.example .env
nano .env  # أو استخدم File Manager Editor
```

**أدخل معلوماتك:**

```env
DB_HOST=localhost
DB_USER=u123456_tamweel
DB_PASSWORD=كلمة_المرور_القوية
DB_NAME=u123456_tamweel
APP_URL=https://yourdomain.com
```

---

## الخطوة 4️⃣: الاتصال بـ SSH

```bash
ssh u123456@yourdomain.com -p 65002
cd ~/public_html
```

> **إذا لم يكن SSH مفعلاً:**
> - اذهب إلى hPanel → Advanced → SSH Access
> - فعّل SSH وأنشئ كلمة مرور

---

## الخطوة 5️⃣: تثبيت Node.js (إذا لزم)

```bash
# تحقق من Node.js
node --version

# إذا لم يكن مثبتاً:
# اتصل بدعم Hostinger لتفعيل Node.js
```

---

## الخطوة 6️⃣: تثبيت الحزم

```bash
cd ~/public_html
npm install
```

⏳ **انتظر 2-3 دقائق حتى انتهاء التثبيت**

---

## الخطوة 7️⃣: إعداد قاعدة البيانات

```bash
npm run setup-db
```

✅ **يجب أن ترى:**

```
✅ Database setup completed successfully!

📝 Default accounts:
   Superadmin: superadmin / SuperAdmin@2025
   Admin:      admin / Admin@2025
   Employee:   admin1 / Admin1@2025
```

---

## الخطوة 8️⃣: تثبيت PM2

```bash
npm install -g pm2
```

---

## الخطوة 9️⃣: تشغيل التطبيق

```bash
pm2 start server.js --name "tamweel-app"
pm2 save
pm2 startup
# انسخ الأمر الذي يظهر وشغله
```

---

## الخطوة 🔟: تفعيل SSL

1. في hPanel، اذهب إلى **Security → SSL**
2. اختر دومينك
3. اضغط **Install SSL**
4. اختر **Free SSL (Let's Encrypt)**
5. انتظر 5-10 دقائق

---

## ✅ اختبار النظام

افتح المتصفح:

```
https://yourdomain.com
```

**سجل دخول بحساب تجريبي:**
- المستخدم: `admin`
- كلمة المرور: `Admin@2025`

---

## 🎉 تم بنجاح!

الآن يمكنك:

1. ✅ تسجيل الدخول
2. ✅ إضافة البنوك والنسب
3. ✅ إدارة العملاء
4. ✅ إنشاء طلبات التمويل
5. ✅ عرض التقارير

---

## ⚡ أوامر PM2 المفيدة

```bash
pm2 status                 # عرض الحالة
pm2 logs tamweel-app      # عرض السجلات
pm2 restart tamweel-app   # إعادة التشغيل
pm2 stop tamweel-app      # إيقاف
pm2 monit                 # المراقبة المباشرة
```

---

## ❓ مشاكل شائعة

### المشكلة: الموقع لا يفتح

**الحل:**

```bash
pm2 status
pm2 logs tamweel-app --lines 50
```

### المشكلة: خطأ في قاعدة البيانات

**الحل:**

```bash
# تحقق من ملف .env
cat .env

# تأكد من صحة معلومات قاعدة البيانات
mysql -u u123456_tamweel -p u123456_tamweel
```

### المشكلة: 502 Bad Gateway

**الحل:**

```bash
# أعد تشغيل التطبيق
pm2 restart tamweel-app

# تحقق من المنفذ
netstat -tuln | grep 3000
```

---

## 🔐 أمان مهم!

⚠️ **غيّر كلمات المرور الافتراضية فوراً!**

1. سجل دخول كـ superadmin
2. اذهب إلى إدارة المستخدمين
3. غيّر جميع كلمات المرور

---

## 💾 النسخ الاحتياطي

**قاعدة البيانات:**

```bash
mysqldump -u u123456_tamweel -p u123456_tamweel > backup_$(date +%Y%m%d).sql
```

**الملفات:**

```bash
cd ~/
tar -czf backup_$(date +%Y%m%d).tar.gz public_html/
```

---

## 📞 الدعم

**إذا واجهت مشكلة:**

1. راجع السجلات: `pm2 logs tamweel-app`
2. راجع الدليل الكامل: `HOSTINGER_DEPLOYMENT_GUIDE.md`
3. تواصل مع دعم Hostinger

---

## 📱 روابط مهمة

- 🏠 الصفحة الرئيسية: `https://yourdomain.com`
- 🔐 تسجيل الدخول: `https://yourdomain.com/login`
- 📊 لوحة التحكم: `https://yourdomain.com/admin/panel`

---

**تهانينا! 🎉 النظام يعمل الآن بنجاح!**

---

**تم التطوير بواسطة:** GenSpark AI Developer  
**الإصدار:** 1.0.0  
**التاريخ:** ديسمبر 2024
