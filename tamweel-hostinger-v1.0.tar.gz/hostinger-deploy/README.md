# 🚀 Tamweel Finance System - Hostinger Edition

نظام إدارة التمويل والعملاء - نسخة Hostinger

## 📦 الملفات المضمنة

```
hostinger-deploy/
├── server.js                         # خادم Express الرئيسي
├── setup-database.js                 # سكريبت إعداد قاعدة البيانات
├── package.json                      # ملف npm
├── .env.example                      # مثال لملف البيئة
├── .htaccess                         # إعدادات Apache
├── public/                           # الملفات الثابتة
│   ├── index.html                   # الصفحة الرئيسية
│   └── login.html                   # صفحة تسجيل الدخول
├── HOSTINGER_DEPLOYMENT_GUIDE.md    # دليل التنصيب الكامل
└── README.md                        # هذا الملف
```

## 🎯 البداية السريعة

### 1. رفع الملفات

```bash
# عبر SSH
cd ~/public_html
# ارفع جميع الملفات هنا
```

### 2. إعداد البيئة

```bash
cp .env.example .env
nano .env
# أدخل معلومات قاعدة البيانات
```

### 3. تثبيت وإعداد

```bash
npm install
npm run setup-db
```

### 4. تشغيل التطبيق

```bash
pm2 start server.js --name "tamweel-app"
pm2 save
```

## 📚 الوثائق الكاملة

للحصول على دليل شامل خطوة بخطوة، راجع:

📖 **[HOSTINGER_DEPLOYMENT_GUIDE.md](./HOSTINGER_DEPLOYMENT_GUIDE.md)**

## ✅ المتطلبات

- ✅ Node.js 18+
- ✅ MySQL 5.7+
- ✅ استضافة Hostinger مع SSH
- ✅ PM2 (للتشغيل في الخلفية)

## 🔐 الحسابات الافتراضية

بعد تشغيل `npm run setup-db`:

- **المدير العام:** `superadmin` / `SuperAdmin@2025`
- **المدير:** `admin` / `Admin@2025`
- **الموظف:** `admin1` / `Admin1@2025`

⚠️ **مهم:** غيّر كلمات المرور فوراً في الإنتاج!

## 🌐 الوصول للنظام

بعد التنصيب، افتح:

```
https://yourdomain.com
```

## 📞 الدعم

إذا واجهت مشكلة:

1. تحقق من السجلات: `pm2 logs tamweel-app`
2. راجع دليل استكشاف الأخطاء في HOSTINGER_DEPLOYMENT_GUIDE.md
3. تواصل مع دعم Hostinger

## 📝 ملاحظات

- ⚡ استخدم PM2 للحصول على أفضل أداء
- 🔒 فعّل SSL من لوحة تحكم Hostinger
- 💾 احتفظ بنسخ احتياطية دورية
- 🔐 غيّر كلمات المرور الافتراضية

---

تم التطوير بواسطة: **GenSpark AI Developer**  
التاريخ: **ديسمبر 2024**  
الإصدار: **1.0.0**
